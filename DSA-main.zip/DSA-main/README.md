# DSA
A collection of LeetCode questions to ace the coding interview! - Created using [LeetHub v2](https://github.com/arunbhardwaj/LeetHub-2.0)

<!---LeetCode Topics Start-->
# LeetCode Topics
## Divide and Conquer
|  |
| ------- |
| [0169-majority-element](https://github.com/Code-bee23/DSA/tree/master/0169-majority-element) |
| [0190-reverse-bits](https://github.com/Code-bee23/DSA/tree/master/0190-reverse-bits) |
| [0191-number-of-1-bits](https://github.com/Code-bee23/DSA/tree/master/0191-number-of-1-bits) |
## Bit Manipulation
|  |
| ------- |
| [0136-single-number](https://github.com/Code-bee23/DSA/tree/master/0136-single-number) |
| [0190-reverse-bits](https://github.com/Code-bee23/DSA/tree/master/0190-reverse-bits) |
| [0191-number-of-1-bits](https://github.com/Code-bee23/DSA/tree/master/0191-number-of-1-bits) |
| [0231-power-of-two](https://github.com/Code-bee23/DSA/tree/master/0231-power-of-two) |
| [0268-missing-number](https://github.com/Code-bee23/DSA/tree/master/0268-missing-number) |
| [0342-power-of-four](https://github.com/Code-bee23/DSA/tree/master/0342-power-of-four) |
## Array
|  |
| ------- |
| [0001-two-sum](https://github.com/Code-bee23/DSA/tree/master/0001-two-sum) |
| [0035-search-insert-position](https://github.com/Code-bee23/DSA/tree/master/0035-search-insert-position) |
| [0075-sort-colors](https://github.com/Code-bee23/DSA/tree/master/0075-sort-colors) |
| [0088-merge-sorted-array](https://github.com/Code-bee23/DSA/tree/master/0088-merge-sorted-array) |
| [0118-pascals-triangle](https://github.com/Code-bee23/DSA/tree/master/0118-pascals-triangle) |
| [0121-best-time-to-buy-and-sell-stock](https://github.com/Code-bee23/DSA/tree/master/0121-best-time-to-buy-and-sell-stock) |
| [0136-single-number](https://github.com/Code-bee23/DSA/tree/master/0136-single-number) |
| [0169-majority-element](https://github.com/Code-bee23/DSA/tree/master/0169-majority-element) |
| [0268-missing-number](https://github.com/Code-bee23/DSA/tree/master/0268-missing-number) |
| [0283-move-zeroes](https://github.com/Code-bee23/DSA/tree/master/0283-move-zeroes) |
| [0704-binary-search](https://github.com/Code-bee23/DSA/tree/master/0704-binary-search) |
| [0977-squares-of-a-sorted-array](https://github.com/Code-bee23/DSA/tree/master/0977-squares-of-a-sorted-array) |
| [1480-running-sum-of-1d-array](https://github.com/Code-bee23/DSA/tree/master/1480-running-sum-of-1d-array) |
## Hash Table
|  |
| ------- |
| [0001-two-sum](https://github.com/Code-bee23/DSA/tree/master/0001-two-sum) |
| [0169-majority-element](https://github.com/Code-bee23/DSA/tree/master/0169-majority-element) |
| [0242-valid-anagram](https://github.com/Code-bee23/DSA/tree/master/0242-valid-anagram) |
| [0268-missing-number](https://github.com/Code-bee23/DSA/tree/master/0268-missing-number) |
## Math
|  |
| ------- |
| [0009-palindrome-number](https://github.com/Code-bee23/DSA/tree/master/0009-palindrome-number) |
| [0069-sqrtx](https://github.com/Code-bee23/DSA/tree/master/0069-sqrtx) |
| [0231-power-of-two](https://github.com/Code-bee23/DSA/tree/master/0231-power-of-two) |
| [0258-add-digits](https://github.com/Code-bee23/DSA/tree/master/0258-add-digits) |
| [0268-missing-number](https://github.com/Code-bee23/DSA/tree/master/0268-missing-number) |
| [0326-power-of-three](https://github.com/Code-bee23/DSA/tree/master/0326-power-of-three) |
| [0342-power-of-four](https://github.com/Code-bee23/DSA/tree/master/0342-power-of-four) |
| [0412-fizz-buzz](https://github.com/Code-bee23/DSA/tree/master/0412-fizz-buzz) |
| [0509-fibonacci-number](https://github.com/Code-bee23/DSA/tree/master/0509-fibonacci-number) |
## Binary Search
|  |
| ------- |
| [0035-search-insert-position](https://github.com/Code-bee23/DSA/tree/master/0035-search-insert-position) |
| [0069-sqrtx](https://github.com/Code-bee23/DSA/tree/master/0069-sqrtx) |
| [0268-missing-number](https://github.com/Code-bee23/DSA/tree/master/0268-missing-number) |
| [0704-binary-search](https://github.com/Code-bee23/DSA/tree/master/0704-binary-search) |
## Sorting
|  |
| ------- |
| [0075-sort-colors](https://github.com/Code-bee23/DSA/tree/master/0075-sort-colors) |
| [0088-merge-sorted-array](https://github.com/Code-bee23/DSA/tree/master/0088-merge-sorted-array) |
| [0169-majority-element](https://github.com/Code-bee23/DSA/tree/master/0169-majority-element) |
| [0242-valid-anagram](https://github.com/Code-bee23/DSA/tree/master/0242-valid-anagram) |
| [0268-missing-number](https://github.com/Code-bee23/DSA/tree/master/0268-missing-number) |
| [0977-squares-of-a-sorted-array](https://github.com/Code-bee23/DSA/tree/master/0977-squares-of-a-sorted-array) |
## Recursion
|  |
| ------- |
| [0231-power-of-two](https://github.com/Code-bee23/DSA/tree/master/0231-power-of-two) |
| [0326-power-of-three](https://github.com/Code-bee23/DSA/tree/master/0326-power-of-three) |
| [0342-power-of-four](https://github.com/Code-bee23/DSA/tree/master/0342-power-of-four) |
| [0509-fibonacci-number](https://github.com/Code-bee23/DSA/tree/master/0509-fibonacci-number) |
## Simulation
|  |
| ------- |
| [0258-add-digits](https://github.com/Code-bee23/DSA/tree/master/0258-add-digits) |
| [0412-fizz-buzz](https://github.com/Code-bee23/DSA/tree/master/0412-fizz-buzz) |
## Number Theory
|  |
| ------- |
| [0258-add-digits](https://github.com/Code-bee23/DSA/tree/master/0258-add-digits) |
## String
|  |
| ------- |
| [0020-valid-parentheses](https://github.com/Code-bee23/DSA/tree/master/0020-valid-parentheses) |
| [0058-length-of-last-word](https://github.com/Code-bee23/DSA/tree/master/0058-length-of-last-word) |
| [0125-valid-palindrome](https://github.com/Code-bee23/DSA/tree/master/0125-valid-palindrome) |
| [0242-valid-anagram](https://github.com/Code-bee23/DSA/tree/master/0242-valid-anagram) |
| [0316-remove-duplicate-letters](https://github.com/Code-bee23/DSA/tree/master/0316-remove-duplicate-letters) |
| [0412-fizz-buzz](https://github.com/Code-bee23/DSA/tree/master/0412-fizz-buzz) |
## Two Pointers
|  |
| ------- |
| [0075-sort-colors](https://github.com/Code-bee23/DSA/tree/master/0075-sort-colors) |
| [0088-merge-sorted-array](https://github.com/Code-bee23/DSA/tree/master/0088-merge-sorted-array) |
| [0125-valid-palindrome](https://github.com/Code-bee23/DSA/tree/master/0125-valid-palindrome) |
| [0283-move-zeroes](https://github.com/Code-bee23/DSA/tree/master/0283-move-zeroes) |
| [0977-squares-of-a-sorted-array](https://github.com/Code-bee23/DSA/tree/master/0977-squares-of-a-sorted-array) |
## Stack
|  |
| ------- |
| [0020-valid-parentheses](https://github.com/Code-bee23/DSA/tree/master/0020-valid-parentheses) |
| [0316-remove-duplicate-letters](https://github.com/Code-bee23/DSA/tree/master/0316-remove-duplicate-letters) |
## Greedy
|  |
| ------- |
| [0316-remove-duplicate-letters](https://github.com/Code-bee23/DSA/tree/master/0316-remove-duplicate-letters) |
## Monotonic Stack
|  |
| ------- |
| [0316-remove-duplicate-letters](https://github.com/Code-bee23/DSA/tree/master/0316-remove-duplicate-letters) |
## Counting
|  |
| ------- |
| [0169-majority-element](https://github.com/Code-bee23/DSA/tree/master/0169-majority-element) |
## Prefix Sum
|  |
| ------- |
| [1480-running-sum-of-1d-array](https://github.com/Code-bee23/DSA/tree/master/1480-running-sum-of-1d-array) |
## Dynamic Programming
|  |
| ------- |
| [0118-pascals-triangle](https://github.com/Code-bee23/DSA/tree/master/0118-pascals-triangle) |
| [0121-best-time-to-buy-and-sell-stock](https://github.com/Code-bee23/DSA/tree/master/0121-best-time-to-buy-and-sell-stock) |
| [0509-fibonacci-number](https://github.com/Code-bee23/DSA/tree/master/0509-fibonacci-number) |
## Memoization
|  |
| ------- |
| [0509-fibonacci-number](https://github.com/Code-bee23/DSA/tree/master/0509-fibonacci-number) |
## Linked List
|  |
| ------- |
| [0083-remove-duplicates-from-sorted-list](https://github.com/Code-bee23/DSA/tree/master/0083-remove-duplicates-from-sorted-list) |
## Design
|  |
| ------- |
| [0933-number-of-recent-calls](https://github.com/Code-bee23/DSA/tree/master/0933-number-of-recent-calls) |
## Queue
|  |
| ------- |
| [0933-number-of-recent-calls](https://github.com/Code-bee23/DSA/tree/master/0933-number-of-recent-calls) |
## Data Stream
|  |
| ------- |
| [0933-number-of-recent-calls](https://github.com/Code-bee23/DSA/tree/master/0933-number-of-recent-calls) |
## Tree
|  |
| ------- |
| [0102-binary-tree-level-order-traversal](https://github.com/Code-bee23/DSA/tree/master/0102-binary-tree-level-order-traversal) |
## Breadth-First Search
|  |
| ------- |
| [0102-binary-tree-level-order-traversal](https://github.com/Code-bee23/DSA/tree/master/0102-binary-tree-level-order-traversal) |
## Binary Tree
|  |
| ------- |
| [0102-binary-tree-level-order-traversal](https://github.com/Code-bee23/DSA/tree/master/0102-binary-tree-level-order-traversal) |
<!---LeetCode Topics End-->